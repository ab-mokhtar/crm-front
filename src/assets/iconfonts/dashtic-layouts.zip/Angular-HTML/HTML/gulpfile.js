var gulp = require('gulp');
sass = require("gulp-sass"),
postcss = require("gulp-postcss");
autoprefixer = require("autoprefixer");
var sourcemaps = require('gulp-sourcemaps'); 
var browserSync = require('browser-sync').create(); 
cssbeautify = require('gulp-cssbeautify');
var beautify = require('gulp-beautify');

/*******************  LTR   ******************/


//_______ task for scss folder to css main style 
gulp.task('watch', function() {
	console.log('Command executed successfully compiling SCSS in assets.');
	 return gulp.src('HTML/assets/scss/**/*.scss') 
		.pipe(sourcemaps.init())                       
		.pipe(sass())
		.pipe(sourcemaps.write(''))   
		.pipe(gulp.dest('HTML/assets/css'))
		.pipe(browserSync.reload({
		  stream: true
	}))
})

//_______task for dark
gulp.task('dark', function(){
   return gulp.src('HTML/assets/css/dark.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})

//_______task for sidemenu
gulp.task('menu', function(){
   return gulp.src('HTML/assets/css/sidemenu.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})

//_______task for skins
gulp.task('skins', function(){
   return gulp.src('HTML/assets/css/skins.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})

//_______task for boxed
gulp.task('boxed', function(){
   return gulp.src('HTML/assets/css/boxed.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})

//_______task for dark-boxed
gulp.task('dark-boxed', function(){
   return gulp.src('HTML/assets/css/dark-boxed.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})

//_______task for closed-sidemenu
gulp.task('closed', function(){
   return gulp.src('HTML/assets/css/closed-sidemenu.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})
//_______task for sidemenu-responsive
gulp.task('responsive', function(){
   return gulp.src('HTML/assets/css/sidemenu-responsive.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})

//_______task for sidemenu-responsive-tabs
gulp.task('tabs', function(){
   return gulp.src('HTML/assets/css/sidemenu-responsive-tabs.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})

//_______task for sidemenu2
gulp.task('menu2', function(){
   return gulp.src('HTML/assets/css/sidemenu2.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})

//_______task for sidemenu3
gulp.task('menu3', function(){
   return gulp.src('HTML/assets/css/sidemenu3.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})

//_______task for sidemenu4
gulp.task('menu4', function(){
   return gulp.src('HTML/assets/css/sidemenu4.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css'));
		
})

/*******************  LTR-Beautify  ******************/

//_______ task for beautifying css
gulp.task('beautify', function() {
    return gulp.src('HTML/assets/css/*.css')
        .pipe(beautify.css({ indent_size: 4 }))
        .pipe(gulp.dest('HTML/assets/css'));
});



/*******************  RTL  ******************/



//_______ task for scss folder to css main style 
gulp.task('rtlwatch', function() {
	console.log('Command executed successfully compiling SCSS in assets.');
	 return gulp.src('HTML/assets/scss-rtl/**/*.scss') 
		.pipe(sourcemaps.init())                       
		.pipe(sass())
		.pipe(sourcemaps.write(''))   
		.pipe(gulp.dest('HTML/assets/css-rtl'))
		.pipe(browserSync.reload({
		  stream: true
	}))
})

//_______task for dark
gulp.task('rtldark', function(){
   return gulp.src('HTML/assets/css-rtl/dark.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})

//_______task for sidemenu
gulp.task('rtlmenu', function(){
   return gulp.src('HTML/assets/css-rtl/sidemenu.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})

//_______task for skins
gulp.task('rtlskins', function(){
   return gulp.src('HTML/assets/css-rtl/skins.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})

//_______task for boxed
gulp.task('rtlboxed', function(){
   return gulp.src('HTML/assets/css-rtl/boxed.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})

//_______task for dark-boxed
gulp.task('rtldark-boxed', function(){
   return gulp.src('HTML/assets/css-rtl/dark-boxed.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})

//_______task for closed-sidemenu
gulp.task('rtlclosed', function(){
   return gulp.src('HTML/assets/css-rtl/closed-sidemenu.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})
//_______task for sidemenu-responsive
gulp.task('rtlresponsive', function(){
   return gulp.src('HTML/assets/css-rtl/sidemenu-responsive.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})

//_______task for sidemenu-responsive-tabs
gulp.task('rtltabs', function(){
   return gulp.src('HTML/assets/css-rtl/sidemenu-responsive-tabs.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})

//_______task for sidemenu2
gulp.task('rtlmenu2', function(){
   return gulp.src('HTML/assets/css-rtl/sidemenu2.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})

//_______task for sidemenu3
gulp.task('rtlmenu3', function(){
   return gulp.src('HTML/assets/css-rtl/sidemenu3.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})


//_______task for sidemenu4
gulp.task('rtlmenu4', function(){
   return gulp.src('HTML/assets/css-rtl/sidemenu4.scss')
        .pipe(sourcemaps.init())
        .pipe(sass())
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
		
})



/*******************  RTL-Beautify  ******************/

//_______ task for beautifying css
gulp.task('rtlbeautify', function() {
    return gulp.src('HTML/assets/css-rtl/*.css')
        .pipe(beautify.css({ indent_size: 4 }))
        .pipe(gulp.dest('HTML/assets/css-rtl'));
});


